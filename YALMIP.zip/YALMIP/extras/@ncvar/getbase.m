function Q=getbase(X)
%GETBASE Internal function to extract all base matrices

Q=double(X.basis);
  
  
      