function var = getvariables(F)
var = getvariables(lmi(F));