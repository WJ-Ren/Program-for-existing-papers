function p = problemclass(F,h)

p = problemclass(lmi(F),h);
